# Curriculum-Vitae
Životopis a podklady k němu. 

# CV-tex
- updated CV from spring 2026
- updated for Junior-Star